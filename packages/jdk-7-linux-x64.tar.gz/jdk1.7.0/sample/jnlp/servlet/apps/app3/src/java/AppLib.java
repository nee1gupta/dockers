public class AppLib {
  public static String getVersion() { return "2.0"; }
}
